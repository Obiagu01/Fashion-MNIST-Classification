

install.packages('tensorflow')
install.packages('keras')

library(tensorflow)
library(keras)

# Define a class for the Fashion MNIST CNN
FashionMNISTCNN <- R6::R6Class(
  "FashionMNISTCNN",
  public = list(
    model = NULL,
    class_names = c("T-shirt/top", "Trouser", "Pullover", "Dress", "Coat",
                    "Sandal", "Shirt", "Sneaker", "Bag", "Ankle boot"),
    # Initialize the model
    initialize = function() {
      self$model <- self$build_model()    
    
      # Build a 6-layer CNN
      build_model = function() {
        model <- keras_model_sequential() %>%
          layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = "relu",
                        input_shape = c(28, 28, 1)) %>%
          layer_max_pooling_2d(pool_size = c(2, 2)) %>%
          layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = "relu") %>%
          layer_max_pooling_2d(pool_size = c(2, 2)) %>%
          layer_conv_2d(filters = 128, kernel_size = c(3, 3), activation = "relu") %>%
          layer_flatten() %>%
          layer_dense(units = 128, activation = "relu") %>%
          layer_dropout(rate = 0.5) %>%
          layer_dense(units = 64, activation = "relu") %>%
          layer_dense(units = 10, activation = "softmax")
        
        model %>% compile(
          optimizer = "adam",
          loss = "categorical_crossentropy",
          metrics = c("accuracy")
        )
        
        return(model)
      },
      
      # Load and preprocess Fashion MNIST data
      load_and_preprocess_data = function() {
        fashion_mnist <- dataset_fashion_mnist()
        c(train_images, train_labels) %<-% fashion_mnist$train
        c(test_images, test_labels) %<-% fashion_mnist$test
        
        # Reshape and normalize images
        train_images <- array_reshape(train_images, c(-1, 28, 28, 1)) / 255
        test_images <- array_reshape(test_images, c(-1, 28, 28, 1)) / 255
        
        # Convert labels to categorical
        train_labels <- to_categorical(train_labels, 10)
        test_labels <- to_categorical(test_labels, 10)
        
        return(list(
          train_images = train_images,
          train_labels = train_labels,
          test_images = test_images,
          test_labels = test_labels
        ))
      } 
      
      # Train the model
      train = function(data, epochs = 10, batch_size = 128) {
        history <- self$model %>% fit(
          data$train_images, data$train_labels,
          epochs = epochs,
          batch_size = batch_size,
          validation_split = 0.2,
          verbose = 1
        )
        return(history)
      }
      # Evaluate the model
      evaluate = function(data) {
        metrics <- self$model %>% evaluate(
          data$test_images, data$test_labels,
          verbose = 0
        )
        cat("Test loss:", metrics$loss, "\n")
        cat("Test accuracy:", metrics$accuracy, "\n")
        return(metrics)
      }
      
      # Predict on new data
      predict_classes = function(images) {
        predictions <- self$model %>% predict(images) %>% k_arg_max(axis = -1)
        return(as.numeric(predictions))
      }
  )
)
# Main execution
main <- function() {
  # Set random seed for reproducibility
  set.seed(123)
  tensorflow::tf$random$set_seed(123)
  
  # Instantiate the CNN
  cnn <- FashionMNISTCNN$new()
  
  # Load and preprocess data
  data <- cnn$load_and_preprocess_data()
  
  # Train the model
  history <- cnn$train(data, epochs = 10, batch_size = 128)
  
  # Evaluate the model
  cnn$evaluate(data)
  
  # Plot training history
  plot(history)
}

# Run the main function
main()
